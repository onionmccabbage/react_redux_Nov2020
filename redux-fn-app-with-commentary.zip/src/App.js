import React, { useCallback, useState, useEffect } from "react"
import { useSelector, shallowEqual, useDispatch } from "react-redux"
import "./App.css"

import { Article } from "./components/Article"
import { AddArticle } from "./components/AddArticle"
import { addArticle, removeArticle, sendEditArticle } from "./store/actionCreators"

const App = () => {
  // useSelector hook: extract data from the Redux store state
  // by using a selector function
  // The entire Redux store state is the only argument
  // Runs whenever the function component renders (cached otherwise)
  // Also subscribes to the Redux store
  // so the selector is run whenever an action is dispatched
  const articles = useSelector(
    (state) => state.articles,
    // useSelector() uses strict === reference equality checks 
    // by default, not shallow equality
    // if a collection of multiple values gets returned
    // EACH member would cause a re-render, 'shallowEqual' prevents this
    shallowEqual
  )
  // Can call useSelector() multiple times in a single function component
  // Each call creates an individual subscription to the Redux store
  // Because of the React update batching behavior in Redux v7
  // a dispatched action that causes multiple useSelector()s in the same component
  // to return new values _should_ only result in a single re-render
  const mode = useSelector(
    (state) => state.mode
  )
  // should we have useState() and/or useSelector() ?
  // useState lets us keep local state in a function component
  // NB we are using array destructuring via these square-brackets
  const [count, setCount] = useState(99) // set the state of count in this component
  // We can have complex stateful objects
  const [fruit, setFruit] = useState('banana')
  const [todos, setTodos] = useState([{ text: 'Learn Hooks' }])
  // We now have fruit and todos as local variables, and we can update them individually
  function handleOrangeClick() {
    // Similar to this.setState({ fruit: 'orange' })
    setFruit('orange')
  }
  const counter = useSelector(state => state.counter)
  // useDispatch hook returns a reference to the dispatch function 
  // from the Redux store. Use it to dispatch actions as needed
  // it is stable, since it will not change in the store
  const dispatch = useDispatch()

  // The useEffect hook (NB comes after the thing it uses)
  // Similar to componentDidMount and componentDidUpdate:
  useEffect(() => {
    // Update the document title using the browser API
    document.title = `state count is ${count}`
  }
    // comment this next line in or out, it still works
    , [count] // Only re-run the effect if count changes
    // a good place to make API calls
  )

  // useCallback will return a memoized version of the callback 
  // that only changes if one of the dependencies has changed
  const saveArticle = useCallback(
    (article) => dispatch(addArticle(article)), [dispatch]
  )

  // useCallback helps to avoid unnecessary re-rendering 
  // by memoizing values as dependencies
  const editArticle = useCallback(
    (article) => dispatch(editArticle(article)), [dispatch]
  )

  let conditional_content
  if (mode == 'edit') {
    conditional_content = <p>Edit Mode</p>
  } else {
    conditional_content = <p>Add Mode</p>
  }

  return (
    <main>
      <h1>Managing Articles with React and Redux</h1>
      {conditional_content}
      <h3>Counter value is currently {counter} and Count is {count}</h3>
      <button onClick={() => setCount(count + 1)}>
        Increase State Count by 1
      </button>
      <AddArticle saveArticle={saveArticle} />
      {/* The order of objects in the map is the same as the insertion order */}
      {articles.map((article) => (
        <Article
          key={article.id}
          article={article}
          removeArticle={removeArticle}
        />
      ))}
    </main>
  )
}

export default App