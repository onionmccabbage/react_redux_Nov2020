// import * as React from "react"
import React, { useState } from "react"

export const AddArticle = ({ saveArticle }) => {
  // we have useState here for article and setArticle
  // article    is local to this component
  // setArticle is local to this component
  const [article, setArticle] = useState({title:'', body:''}) // or React.useState()

  // the article fields are 'controlled'
  const handleArticleData = (e) => {
    setArticle({ // remember setArticle is a constant
      ...article, // article is a constant
      [e.currentTarget.id]: e.currentTarget.value,
    })
  }

  const addNewArticle = (e) => {
    e.preventDefault()
    saveArticle(article)
    // clear down the fields in this component
    let empty_article = {id:-1, title:'', body:''}
    setArticle({ // remember setArticle is a constant
      ...empty_article, // NB article is a constant, so this does a refresh
    })
    // or for uncontrolled fields (this example is incomplete)
    // https://reactgo.com/clear-input-field-value-react/
    // this.title.value = ''
    // this.body.value = ''
  }

  return (
    <form onSubmit={addNewArticle} className="Add-article">
      {/* these are controlled fields */}
      <input
        type="text"
        id="title"
        value={article.title}
        placeholder="Title"
        onChange={handleArticleData}
      />
      <input
        type="text"
        id="body"
        value={article.body}
        placeholder="Body"
        onChange={handleArticleData}
      />
      <button disabled={article.title === '' || article.body === '' ? true : false}>
        Add article
      </button>
    </form>
  )
}