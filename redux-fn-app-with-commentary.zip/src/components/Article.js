import React, { useCallback } from "react"
import { useDispatch, useSelector } from "react-redux"
import * as actionTypes from "../store/actionTypes"

// for next 2 lines see https://react-redux.js.org/api/hooks#useselector
// export const Article = (props) => { // if we wanted to pick which props to pass in (rather than entire article)
//   const article = useSelector(state => state.articles[props.id]) // etc.

// here we must ensure that each component instance 
// gets its own selector instance (this component is used in a map (iterated))
export const Article = ({ article, removeArticle }) => {
  const dispatch = useDispatch()

  // useCallback returns a memoized callback
  // https://reactjs.org/docs/hooks-reference.html#usecallback
  // This avoids unnecessary rendering of child components 
  // due to the changed callback reference
  // https://react-redux.js.org/api/hooks#usedispatch
  const deleteArticle = useCallback(
    (article) => dispatch(removeArticle(article)),
    [dispatch, removeArticle]
    // or (not currently working...)
    // (article) => dispatch({type:actionTypes.REMOVE_ARTICLE, payload:article}),
  )

  // or we can just invoke the action by dispatching it directly
  const onDelete = (article) => {
    // removeArticle expects a payload of just the article (not data containing the article)
    dispatch(removeArticle(article))
  }

  return (
    <div className="Article">
      <div>
        <h1>{article.id} {article.title}</h1>
        <p>{article.body}</p>
      </div>
      <button onClick={() => deleteArticle(article)}>Delete</button>
      {/* <button onClick={() => onDelete(article)}>Delete</button> */}
    </div>
  )
}