import * as actionTypes from "./actionTypes"

export function addArticle(article) {
  const action = {
    type: actionTypes.ADD_ARTICLE,
    article,
  }
  return simulateHttpRequest(action)
}
export function removeArticle(article) {
  const action = {
    type: actionTypes.REMOVE_ARTICLE,
    article,
  }
  return simulateHttpRequest(action)
}
export function simulateHttpRequest(action) {
  return (dispatch) => {
    setTimeout(() => {
      dispatch(action)
    }, 800)
  }
}