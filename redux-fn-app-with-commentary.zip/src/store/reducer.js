import * as actionTypes from "./actionTypes"
// load some static json with the initial articles collection
let articles = require('../data/articles.json')

const initialState = {
  articles: articles,
  counter: articles.length, // an arbitrary numeric counter
  mode: "add" // could change between add and edit modes
}

const reducer = (
  state = initialState,
  action
) => {
  switch (action.type) {
    case actionTypes.ADD_ARTICLE:
      const newArticle = {
        id: state.counter,// Math.random() is not really unique
        title: action.article.title,
        body: action.article.body,
      }
      return {
        ...state,
        articles: state.articles.concat(newArticle),
        counter:state.counter+1  // not an ideal technique!!
      }
    case actionTypes.REMOVE_ARTICLE:
      const updatedArticles = state.articles.filter(
        article => article.id !== action.article.id
      )
      return {
        ...state,
        articles: updatedArticles,
      }
    default:
      return state
  }
}

export default reducer