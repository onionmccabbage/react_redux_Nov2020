import React from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Questions from "./features/Questions/Questions";
import QuestionDetail from "./features/QuestionDetail/QuestionDetail";

// React Routing in use - here we have two routes defined
const Routes = () => {
  return (
    <Router>
      <Switch>
        {/* the root route */}
        <Route exact path="/">
          <Questions />
        </Route>
        {/* route to details passing id as only parameter*/}
        <Route path="/question/:id">
          <QuestionDetail />
        </Route>
      </Switch>
    </Router>
  );
};

export default Routes;
