import React, { useState } from "react"
// needed for hooks
import { useDispatch, useSelector } from "react-redux"
// import { CSSTransition } from "react-transition-group"
import { Link } from "react-router-dom"

import './Questions.css';

import {
  selectQuestions,
  addQuestion,
  removeQuestion,
  // editQuestion,
} from "./questionSlice"

const Questions = () => {
  // some hooks!!                     // set local state values to false
  const [showAddQuestion, setShowAddQuestion] = useState(false)
  const [title, setTitle] = useState("") // empty 
  const [body, setBody] = useState("")
  // bring in resux state via useSelector
  const questions = useSelector(selectQuestions)
  // and we also need the actions
  const dispatch = useDispatch()

  const onSubmit = () => {
    let data = {
      id: questions.length + 1,
      title: title,
      body,
    }
    dispatch(addQuestion(data))
    setShowAddQuestion(false)
    setTitle("")
    setBody("")
  }

  // const onDelete=(id)=>{
  //   let data = {
  //     id: id
  //   }
  //   dispatch(removeQuestion(data))
  // }

  return (
    <aside>
      <ul>
        {questions && questions.length > 0 ? (
          questions.map((question, index) => {
            return (
              <li key={index}>
                <Link to={`/question/${question.id}`}><h5>{question.title}</h5></Link>
                {/* remember this old trick onClick={ ()=>{ onDelete() } } - pass a function to ensure bindings!! */}
                {/* <button id='btnDelete' onClick={onDelete(question.id)}>Delete</button> */}
              </li>
            )
          })
        ) : (
            <div>No Data Found</div>
          )}
      </ul>
      <button onClick={() => setShowAddQuestion(true)}>Add Question</button>
      {showAddQuestion ? (
        <form>
          <section>
            <label>Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </section>
          <section>
            <label>Body</label>
            <input
              type="textarea"
              value={body}
              onChange={(e) => setBody(e.target.value)}
            />
          </section>
          <button onClick={onSubmit}>Submit</button>
        </form>
        //  or lese show nothing!
      ) : ( "" )} 
    </aside>
  )
}

export default Questions
