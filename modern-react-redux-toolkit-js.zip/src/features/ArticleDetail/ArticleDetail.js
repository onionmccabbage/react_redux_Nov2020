import React from "react" // { useState } 
import { useSelector } from "react-redux";
import { useParams  } from "react-router-dom" // { useHistory }

import Comments from "../Comments/Comments";

const ArticleDetail = () => { // (props)=>{} is still permitted
  const { id } = useParams();
  if (!id) {
  }
  const articleDetail = useSelector((state) => {
    let article = state.articles.find((article) => article.id === id);
    return article;
  });

  return (
    <aside>
        <h3>Title: {articleDetail && articleDetail.title} </h3>
        <h4>Body: {articleDetail && articleDetail.body}</h4>
      {articleDetail ? <Comments id={articleDetail.id} /> : null}
    </aside>
  );
};

export default ArticleDetail;
