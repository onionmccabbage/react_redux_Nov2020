import React, { useState } from "react"
import { useSelector, useDispatch } from "react-redux"
import { addComment } from "./commentsSlice"

const Comments = ({ id }) => {
  const [comment, setComment] = useState("")

  const comments = useSelector((state) => {
    let comments = state.comments.filter((comment) => comment.questionId === id)
    return comments;
  });
  const dispatch = useDispatch()

  // a controlled input field
  const onAddComment = (e) => {
    if (e.key !== "Enter") {
      return;
    }
    if (e.key === "Enter") {
      let data = {
        id: comments && comments.length > 0 ? comments.length + 1 : 1,
        comment: comment,
        questionId: id,
      };
      dispatch(addComment(data))
      setComment("")
    }
  }
  return (
    <aside>
      <h3>Comments</h3>
      <ol>
        {comments &&
          comments.map((comment) => (
            <li key={comment.id}>{comment.comment}</li>
          ))}
      </ol>
      <input
        type="text"
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        onKeyPress={onAddComment} />
    </aside>
  )
}

export default Comments
