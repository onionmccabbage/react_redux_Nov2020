// React hooks
import React, { useState, useCallback } from "react"
// React Redux hooks
import { useDispatch, useSelector } from "react-redux"
import { Link } from "react-router-dom"

import './Articles.css';

import {
  selectArticles,
  addArticle,
  removeArticle,
  // editArticle,
} from "./articleSlice"

const Articles = () => {
  // some hooks!!                     // set local state values to false
  const [showAddArticle, setShowAddArticle] = useState(false)
  const [title, setTitle] = useState("") // empty 
  const [body, setBody] = useState("")
  // bring in resux state via useSelector
  const articles = useSelector(selectArticles)
  // and we also need the actions
  const dispatch = useDispatch()

  const onSubmit = () => {
    let data = {
      id: articles.length + 1,
      title: title,
      body,
    }
    dispatch(addArticle(data))
    setShowAddArticle(false)
    setTitle("")
    setBody("")
  }

  // const deleteArticle = (article) => {
  //   // removeArticle expects a payload of just the article (not data containing the article)
  //   dispatch(removeArticle(article))
  // }
  // other way, using useCallback()
  // useCallback returns a memoized callback
  // https://reactjs.org/docs/hooks-reference.html#usecallback
  // This avoids unnecessary rendering of child components 
  // due to the changed callback reference
  // https://react-redux.js.org/api/hooks#usedispatch
  // so here it is with useCallback
  const deleteArticle = useCallback(
    (article) => dispatch(removeArticle(article))
  )

return (
  <aside>
    {articles && articles.length > 0 ? (
      articles.map((article, index) => {
        return (
          <aside className="Article" key={index}>
            {/* <Link to={`/article/${article.id}`}><h5>{article.title}</h5> */}
            <h1><Link to={`/article/${article.id}`}>{article.id} {article.title}</Link></h1>
            <p>{article.body}</p>
            {/* remember this old trick - pass a function to ensure bindings!! */}
            <button id='btnDelete' onClick={ ()=>{ deleteArticle(article) } }>Delete</button>
          </aside>
        )
      })
    ) : (
        <div>No Data Found</div>
      )}
    <button onClick={() => setShowAddArticle(true)}>Add Article</button>
    {showAddArticle ? (
      <form>
        <section>
          <label>Title</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </section>
        <section>
          <label>Body</label>
          <input
            type="textarea"
            value={body}
            onChange={(e) => setBody(e.target.value)}
          />
        </section>
        <button onClick={onSubmit}>Submit</button>
      </form>
      //  or lese show nothing!
    ) : ("")}
  </aside>
)
}

export default Articles
