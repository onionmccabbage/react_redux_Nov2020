import { configureStore } from '@reduxjs/toolkit';
import articleReducer from "../features/Articles/articleSlice";
import commentReducer from "../features/Comments/commentsSlice";

export default configureStore({
  reducer: {
    articles: articleReducer,
    comments: commentReducer,
  },
});
